package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    TextView thePlace, description, temp, theHigh, theLow, feelsLike, humidity, visibility, windSpeed, theLatitude, theLongitude;
    String longitudeValue, latitudeValue, theLocation;
    EditText userInput;
    Button searchButton, myLocation, showMap;
    String getURL = "";
    private static final int REQUEST_CODE_PERMISSION = 2;
    String mPermission = Manifest.permission.ACCESS_FINE_LOCATION;

    // GPSTracker class
    GPSTracker gps;

    public static final String transferLat = "com.example.weatherapp.latitudeValue";
    public static final String transferLon = "com.example.weatherapp.longitudeValue";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            if (ActivityCompat.checkSelfPermission(this, mPermission)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this, new String[]{mPermission},
                        REQUEST_CODE_PERMISSION);

                // If any permission above not allowed by user, this condition will
                //execute every time, else your else part will work
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        thePlace = (TextView)findViewById(R.id.thePlace);
        description = (TextView)findViewById(R.id.description);
        temp = (TextView)findViewById(R.id.temp);
        theHigh = (TextView)findViewById(R.id.theHigh);
        theLow = (TextView)findViewById(R.id.theLow);
        feelsLike = (TextView)findViewById(R.id.feelsLike);
        humidity = (TextView)findViewById(R.id.humidity);
        visibility = (TextView)findViewById(R.id.visibility);
        windSpeed = (TextView)findViewById(R.id.windSpeed);
        theLatitude = (TextView)findViewById(R.id.theLatitude);
        theLongitude = (TextView)findViewById(R.id.theLongitude);
        userInput = (EditText)findViewById(R.id.userInput);
        searchButton = (Button)findViewById(R.id.searchButton);
        myLocation = (Button)findViewById(R.id.myLocation);
        showMap = (Button)findViewById(R.id.showMap);



        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getURL = userInput.getText().toString();

                if(Utility.numberOrNot(getURL)){
                    String theURL = "https://api.openweathermap.org/data/2.5/weather?zip="+getURL+"&appid=1b8fe95bda81875bd8dc9263cfd58b13";
                    getWeather(theURL);
                    showMap.setVisibility(View.VISIBLE);
                }
                else{
                    String theURL = "https://api.openweathermap.org/data/2.5/weather?q="+getURL+"&appid=1b8fe95bda81875bd8dc9263cfd58b13";
                    getWeather(theURL);
                    showMap.setVisibility(View.VISIBLE);
                }

            }
        });

        myLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // create class object
                gps = new GPSTracker(MainActivity.this);

                // check if GPS enabled
                if(gps.canGetLocation()){

                    double latitude = gps.getLatitude();
                    double longitude = gps.getLongitude();

                    // \n is for new line
                    Toast.makeText(getApplicationContext(), "Your Location is - \nLat: "
                            + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();

                    String theURL = "https://api.openweathermap.org/data/2.5/weather?lat="+latitude+"&lon="+longitude+"&appid=1b8fe95bda81875bd8dc9263cfd58b13";
                    getWeather(theURL);
                    showMap.setVisibility(View.VISIBLE);
                }else{
                    // can't get location
                    // GPS or Network is not enabled
                    // Ask user to enable GPS/network in settings
                    gps.showSettingsAlert();
                }

            }
        });

        showMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();

                Toast.makeText(getApplicationContext(), "Brandon Michael Que\nZ23479912", Toast.LENGTH_LONG).show();
            }
        });

        //getWeather();
    }

    public void openActivity2(){
        Intent intent = new Intent(this, Activity2.class);
        intent.putExtra(transferLat, latitudeValue);
        intent.putExtra(transferLon, longitudeValue);
        startActivity(intent);
    }

    public void getWeather(String theURL){

        String url= theURL;



        JsonObjectRequest getData = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONObject mainObject = response.getJSONObject("main"); //mainObject is now connected to "main" in the JSON
                    JSONArray array = response.getJSONArray("weather");
                    JSONObject object = array.getJSONObject(0); //object is now connected to array
                    JSONObject windObject = response.getJSONObject("wind");
                    JSONObject coordObject = response.getJSONObject("coord");

                    String theTemp = String.valueOf(mainObject.getDouble("temp"));
                    String theDescription = object.getString("description");
                    theLocation = response.getString("name");
                    String tempMin = String.valueOf(mainObject.getDouble("temp_min"));
                    String tempMax = String.valueOf(mainObject.getDouble("temp_max"));
                    String theFeelsLike = String.valueOf(mainObject.getDouble("feels_like"));
                    String theHumidity = String.valueOf(mainObject.getDouble("humidity"));
                    String theVisibility = response.getString("visibility");
                    String theWindSpeed = String.valueOf(windObject.getDouble("speed"));
                    longitudeValue = String.valueOf(coordObject.getDouble("lon"));
                    latitudeValue = String.valueOf(coordObject.getDouble("lat"));



                    double temp_int = Double.parseDouble(theTemp); //temp is in kelvin right now so we have to convert to fahrenheit before displaying
                    double fahrenheit = ((temp_int - 273.15)*(1.8))+32;
                    fahrenheit = Math.round(fahrenheit); //we round, but it still has .0 at the end so i'll make this an int
                    int fahrenheit_int = (int)fahrenheit;
                    temp.setText(String.valueOf(fahrenheit_int)+"\u00B0F");

                    thePlace.setText(theLocation);
                    description.setText(theDescription);

                    double tempMin_int = Double.parseDouble(tempMin);
                    double fahrenheitMin = ((tempMin_int - 273.15)*(1.8))+32;
                    fahrenheitMin = Math.round(fahrenheitMin); //we round, but it still has .0 at the end so i'll make this an int
                    int fahrenheitMin_int = (int)fahrenheitMin;
                    theLow.setText("L: " + String.valueOf(fahrenheitMin_int)+"\u00B0F");

                    double tempMax_int = Double.parseDouble(tempMax);
                    double fahrenheitMax = ((tempMax_int - 273.15)*(1.8))+32;
                    fahrenheitMax = Math.round(fahrenheitMax); //round to 2 decimal places
                    int fahrenheitMax_int = (int)fahrenheitMax;
                    theHigh.setText("H: "+String.valueOf(fahrenheitMax_int)+"\u00B0F");

                    double feelsLike_int = Double.parseDouble(theFeelsLike);
                    double fahrenheitFeelsLike = ((feelsLike_int - 273.15)*(1.8))+32;
                    fahrenheitFeelsLike = Math.round(fahrenheitFeelsLike); //round to 2 decimal places
                    int fahrenheitFeelsLike_int = (int)fahrenheitFeelsLike;
                    feelsLike.setText("Feels Like: "+String.valueOf(fahrenheitFeelsLike_int)+"\u00B0F");

                    humidity.setText("Humidity: "+theHumidity+"%");

                    double visibility_int = Double.parseDouble(theVisibility);
                    double visibilityIs = (visibility_int / 1609);
                    visibilityIs = Math.round(visibilityIs); //round to 2 decimal places
                    int visibilityIS_int = (int)visibilityIs;
                    visibility.setText("Visibility: "+String.valueOf(visibilityIS_int)+" mi");

                    double windSpeed_int = Double.parseDouble(theWindSpeed);
                    double windSpeedIs = (windSpeed_int * 2.237);
                    windSpeedIs= Math.round(windSpeedIs); //round to 2 decimal places
                    int windSpeedIs_int = (int)windSpeedIs;
                    windSpeed.setText("Wind Speed: "+String.valueOf(windSpeedIs_int)+" mph");

                    theLongitude.setText("Lon: "+longitudeValue);
                    theLatitude.setText("Lat: "+latitudeValue);


                } catch(JSONException theError){
                    theError.printStackTrace();
                }
            }
        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){

            }
        });

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(getData);

    }
}

class Utility{
    static boolean numberOrNot(String userInput){
        try{
            Integer.parseInt(userInput);
        }catch(NumberFormatException ex){
            return false;
        }
        return true;
    }
}